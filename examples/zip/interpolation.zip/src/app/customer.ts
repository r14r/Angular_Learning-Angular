export class Customer {
  name: string;
}
